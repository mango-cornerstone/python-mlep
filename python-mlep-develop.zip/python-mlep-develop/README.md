# MLEP Client
Interact with an EnergyPlus simulation during runtime using the BCVTB protocol.

# Usage
`pip install mlep`

Up to date usage can be found in the alfalfa repository, likely in [osm_model_advancer](https://github.com/NREL/alfalfa/blob/develop/alfalfa_worker/step_sim/osm_model_advancer.py) function.  As tests get added, usage will be updated.

# Releasing
See [release info here](https://gist.github.com/corymosiman12/26fb682df2d36b5c9155f344eccbe404#releasing)
